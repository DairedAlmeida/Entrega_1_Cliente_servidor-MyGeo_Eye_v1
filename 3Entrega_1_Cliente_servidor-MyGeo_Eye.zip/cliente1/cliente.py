import socket
import os

class Client:
    def __init__(self, host='localhost', port=6000):
        self.host = host
        self.port = port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.connect((self.host, self.port))
        print("[DEBUG] Conectado ao servidor")

    def upload_image(self, file_path):
        if os.path.exists(file_path):
            file_name = os.path.basename(file_path)
            self.client_socket.send(f"UPLOAD {file_name}".encode())
            print(f"[DEBUG] Enviando arquivo: {file_name}")

            with open(file_path, 'rb') as f:
                while True:
                    dados = f.read(4096)
                    if not dados:
                        break
                    self.client_socket.send(dados)
            self.client_socket.send(b"FIM")
            print(self.client_socket.recv(1024).decode())
        else:
            print("Arquivo não encontrado. Tente novamente.")

    def list_images(self):
        print("[DEBUG] Solicitando lista de imagens...")
        self.client_socket.send("LIST".encode())
        images = self.client_socket.recv(1024).decode()
        print(f"Imagens: {images}")

    def download_image(self, file_name):
        print(f"[DEBUG] Solicitando download da imagem: {file_name}")
        self.client_socket.send(f"DOWNLOAD {file_name}".encode())
        
        # Recebe a primeira resposta do servidor
        response = self.client_socket.recv(1024)
        if response == b"Arquivo nao encontrado":
            print("[DEBUG] O arquivo solicitado não foi encontrado no servidor.")
            print("Erro: Arquivo não encontrado.")
        else:
            print("[DEBUG] Iniciando o download da imagem...")

            # Se a imagem existir, continue recebendo os dados
            with open(file_name, 'wb') as f:
                while True:
                    dados = self.client_socket.recv(4096)
                    if dados.endswith(b"FIM"):  # Verifica se chegou no fim da transmissão
                        f.write(dados[:-3])  # Remove o "FIM" do final
                        break
                    f.write(dados)
            
            print(f"Imagem {file_name} baixada com sucesso.")

    def delete_image(self, file_name):
        print(f"[DEBUG] Solicitando deleção da imagem: {file_name}")
        self.client_socket.send(f"DELETE {file_name}".encode())
        print(self.client_socket.recv(1024).decode())

    def close(self):
        print("[DEBUG] Fechando conexão com o servidor")
        self.client_socket.close()

    def run(self):
        while True:
            print("\nEscolha uma opção:")
            print("1. Upload um arquivo de imagem de satélite")
            print("2. Listar as imagens inseridas")
            print("3. Baixar uma imagem inserida")
            print("4. Deletar uma imagem")
            print("5. Sair")

            choice = input("Digite sua escolha (1-5): ")

            if choice == '1':
                file_path = input("Digite o caminho do arquivo de imagem: ")
                self.upload_image(file_path)

            elif choice == '2':
                self.list_images()

            elif choice == '3':
                file_name = input("Digite o nome da imagem a ser baixada: ")
                self.download_image(file_name)

            elif choice == '4':
                file_name = input("Digite o nome da imagem a ser deletada: ")
                self.delete_image(file_name)

            elif choice == '5':
                print("Saindo...")
                self.close()
                break

            else:
                print("Escolha inválida. Tente novamente.")

if __name__ == "__main__":
    client = Client()
    client.run()
