import socket
import os

class Cluster:
    DIRETORIO_IMAGENS = "imagens"

    def __init__(self, host='localhost', porta=7000):
        if not os.path.exists(self.DIRETORIO_IMAGENS):
            os.makedirs(self.DIRETORIO_IMAGENS)

        self.cluster_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.cluster_socket.bind((host, porta))
        self.cluster_socket.listen(5)
        print(f"[DEBUG] Cluster ouvindo em {host}:{porta}")

    def tratar_requisicao(self, server_socket):
        try:
            while True:
                requisicao = server_socket.recv(1024)
                if not requisicao:
                    print("[DEBUG] Cliente desconectado")
                    break
                requisicao = requisicao.decode()
                print(f"[DEBUG] Requisição recebida: {requisicao}")
                self.processar_comando(requisicao, server_socket)

        except Exception as e:
            print(f"[DEBUG] Erro ao tratar cliente: {e}")
        finally:
            server_socket.close()

    def processar_comando(self, requisicao, server_socket):
        comando, *args = requisicao.split()

        if comando == "UPLOAD":
            self.upload_imagem(server_socket, args)
        elif comando == "LIST":
            self.listar_imagens(server_socket)
        elif comando == "DOWNLOAD":
            self.download_imagem(server_socket, args)
        elif comando == "DELETE":
            self.deletar_imagem(server_socket, args)
        else:
            print("[DEBUG] Comando inválido.")

    def upload_imagem(self, server_socket, args):
        nome_arquivo = args[0]
        caminho_arquivo = os.path.join(self.DIRETORIO_IMAGENS, nome_arquivo)

        with open(caminho_arquivo, 'wb') as f:
            while True:
                try:
                    dados = server_socket.recv(4096)
                    if not dados:
                        break
                    if dados.endswith(b"FIM"):
                        print(f"[DEBUG] Recebido marcador 'FIM' do cluster. Transmissão concluída.")
                        break
                    f.write(dados)
                except Exception as e:
                    print(f"[DEBUG] Erro ao receber dados: {e}")
                    break
        print(f"[DEBUG] Imagem {nome_arquivo} recebida no cluster.")

    def listar_imagens(self, server_socket):
        imagens = os.listdir(self.DIRETORIO_IMAGENS)
        if not imagens:
            print("[DEBUG] Nenhuma imagem encontrada no cluster.")
            server_socket.send("Nenhuma imagem encontrada.".encode())
        else:
            imagens_str = ", ".join(imagens)
            print(f"[DEBUG] Enviando lista de imagens: {imagens_str}")
            server_socket.send(imagens_str.encode())

    def download_imagem(self, server_socket, args):
        nome_arquivo = args[0]
        caminho_arquivo = os.path.join(self.DIRETORIO_IMAGENS, nome_arquivo)

        if os.path.exists(caminho_arquivo):
            with open(caminho_arquivo, 'rb') as f:
                while True:
                    dados = f.read(4096)  # Envia em blocos de 4KB
                    if not dados:
                        break
                    if dados.endswith(b"FIM"):
                        server_socket.send(dados[:-3])
                        break
                    server_socket.send(dados)  # Envie os dados da imagem
            # Enviar um marcador de fim para o servidor
            server_socket.send(b"FIM")
            print(f"[DEBUG] Imagem {nome_arquivo} enviada para o servidor.")
        else:
            server_socket.send(b"Arquivo nao encontrado")

    def deletar_imagem(self, server_socket, args):
        nome_arquivo = args[0]
        caminho_arquivo = os.path.join(self.DIRETORIO_IMAGENS, nome_arquivo)
        if os.path.exists(caminho_arquivo):
            os.remove(caminho_arquivo)
            server_socket.send(f"Imagem {nome_arquivo} deletada".encode())
        else:
            server_socket.send(f"Imagem {nome_arquivo} não encontrada".encode())

    def iniciar(self):
        while True:
            server_socket, endereco = self.cluster_socket.accept()
            print(f"[DEBUG] Conexão recebida de {endereco}")
            self.tratar_requisicao(server_socket)

if __name__ == "__main__":
    cluster = Cluster()
    cluster.iniciar()
