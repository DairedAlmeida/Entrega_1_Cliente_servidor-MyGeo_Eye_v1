import socket
import threading
import time  # Adiciona o time para permitir o sleep entre tentativas de reconexão

class Servidor:
    def __init__(self, host='localhost', porta=6000, cluster_host='localhost', cluster_porta=7000):
        self.host = host
        self.porta = porta
        self.cluster_host = cluster_host
        self.cluster_porta = cluster_porta
        self.servidor_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.servidor_socket.bind((self.host, self.porta))
        self.servidor_socket.listen(5)
        print(f"[DEBUG] Servidor ouvindo em {self.host}:{self.porta}")

        self.cluster_socket = None
        self.conectar_cluster()

    def conectar_cluster(self):
        """Tenta conectar ao cluster com reconexões automáticas."""
        while self.cluster_socket is None:
            try:
                print(f"[DEBUG] Tentando conectar ao cluster em {self.cluster_host}:{self.cluster_porta}...")
                self.cluster_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.cluster_socket.connect((self.cluster_host, self.cluster_porta))
                print(f"[DEBUG] Conexão com o cluster estabelecida")
            except ConnectionRefusedError:
                print(f"[DEBUG] Conexão recusada. Tentando novamente em 5 segundos...")
                self.cluster_socket = None
                time.sleep(5)  # Espera 5 segundos antes de tentar novamente

    def reconectar_cluster(self):
        """Tenta reconectar ao cluster caso a conexão caia."""
        print("[DEBUG] Tentando reconectar ao cluster...")
        self.desconectar_cluster()
        self.conectar_cluster()

    def desconectar_cluster(self):
        """Desconecta do cluster."""
        if self.cluster_socket:
            print("[DEBUG] Desconectando do cluster")
            self.cluster_socket.close()
            self.cluster_socket = None

    def tratar_cliente(self, cliente_socket):
        try:
            while True:
                requisicao = cliente_socket.recv(1024)
                if not requisicao:
                    print("[DEBUG] Cliente desconectado")
                    break
                requisicao = requisicao.decode()
                print(f"[DEBUG] Requisição recebida: {requisicao}")
                self.processar_comando(requisicao, cliente_socket)

        except Exception as e:
            print(f"[DEBUG] Erro ao tratar cliente: {e}")
        finally:
            cliente_socket.close()

    def processar_comando(self, requisicao, cliente_socket):
        comando, *args = requisicao.split()

        if comando == "UPLOAD":
            self.processar_upload(args, cliente_socket)

        elif comando == "LIST":
            self.processar_list(cliente_socket)

        elif comando == "DOWNLOAD":
            self.processar_download(args, cliente_socket)

        elif comando == "DELETE":
            self.processar_delete(args, cliente_socket)

        else:
            cliente_socket.send("Comando inválido".encode())

    def verificar_conexao_cluster(self):
        """Verifica se a conexão com o cluster está ativa."""
        try:
            self.cluster_socket.send(b"PING")  # Verifica se a conexão está ativa
        except (BrokenPipeError, ConnectionResetError):
            print("[DEBUG] Conexão com o cluster perdida. Reconectando...")
            self.reconectar_cluster()

    def processar_upload(self, args, cliente_socket):
        nome_arquivo = args[0]
        print(f"[DEBUG] Recebendo imagem {nome_arquivo} do cliente e enviando para o cluster...")

        self.verificar_conexao_cluster()
        self.cluster_socket.send(f"UPLOAD {nome_arquivo}".encode())
        
        while True:
            dados = cliente_socket.recv(4096)
            if not dados:
                print("[DEBUG] Nenhum dado recebido, encerrando transmissão.")
                break
            if dados.endswith(b"FIM"):
                self.cluster_socket.send(dados[:-3])
                print(f"[DEBUG] Recebido marcador 'FIM'. Transmissão concluída.")
                break
            self.cluster_socket.send(dados)

        self.cluster_socket.send(b"FIM")
        cliente_socket.send("Upload bem-sucedido".encode())
        print(f"[DEBUG] Imagem {nome_arquivo} enviada para o cluster")

    def processar_list(self, cliente_socket):
        print("[DEBUG] Solicitando lista de imagens ao cluster...")
        self.verificar_conexao_cluster()
        self.cluster_socket.send("LIST".encode())
        imagens = self.cluster_socket.recv(1024).decode()
        print(f"[DEBUG] Imagens recebidas do cluster: {imagens}")
        cliente_socket.send(imagens.encode())

    def processar_download(self, args, cliente_socket):
        nome_arquivo = args[0]
        try:
            self.verificar_conexao_cluster()
            self.cluster_socket.send(f"DOWNLOAD {nome_arquivo}".encode())
            print(f"[DEBUG] Solicitando a imagem {nome_arquivo} ao cluster...")

            response = self.cluster_socket.recv(4096)

            if response == b"Arquivo nao encontrado":
                print(f"[DEBUG] Arquivo {nome_arquivo} não encontrado no cluster.")
                cliente_socket.send("Arquivo nao encontrado".encode())
            else:
                print(f"[DEBUG] Enviando imagem {nome_arquivo} para o cliente.")
                while True:
                    dados = self.cluster_socket.recv(4096)
                    if not dados:
                        print("[DEBUG] Nenhum dado recebido, encerrando transmissão.")
                        break
                    if dados.endswith(b"FIM"):
                        cliente_socket.send(dados[:-3])
                        print(f"[DEBUG] Recebido marcador 'FIM'. Transmissão concluída.")
                        break
                    cliente_socket.send(dados)

                cliente_socket.send(b"FIM")
                print(f"Imagem {nome_arquivo} enviada com sucesso ao cliente.")
        except FileNotFoundError:
            cliente_socket.send("Arquivo não encontrado".encode())

    def processar_delete(self, args, cliente_socket):
        nome_arquivo = args[0]
        self.verificar_conexao_cluster()
        self.cluster_socket.send(f"DELETE {nome_arquivo}".encode())
        resposta = self.cluster_socket.recv(1024).decode()
        cliente_socket.send(resposta.encode())

    def iniciar(self):
        while True:
            cliente_socket, endereco = self.servidor_socket.accept()
            print(f"[DEBUG] Conexão de {endereco}")
            tratador_cliente = threading.Thread(target=self.tratar_cliente, args=(cliente_socket,))
            tratador_cliente.start()

if __name__ == "__main__":  
    servidor = Servidor()
    servidor.iniciar()
